-- do not make any changes to this file

-- Ambulance / LAFD
txd = engineLoadTXD ("files/resc.txd")
engineImportTXD (txd, 416)
dff = engineLoadDFF ("files/resc.dff")
engineReplaceModel (dff,416,true)

-- Buffalo / GTR34
txd = engineLoadTXD ("files/buffalo.txd")
engineImportTXD (txd, 402)
dff = engineLoadDFF ("files/buffalo.dff")
engineReplaceModel (dff,402,true)

-- Burrito / Custom
txd = engineLoadTXD ("files/custvan.txd")
engineImportTXD (txd, 482)
dff = engineLoadDFF ("files/custvan.dff")
engineReplaceModel (dff,482,true)

-- Comet / Custom
txd = engineLoadTXD ("files/comet.txd")
engineImportTXD (txd, 480)
dff = engineLoadDFF ("files/comet.dff")
engineReplaceModel (dff,480,true)

-- DFT-30 / Custom
txd = engineLoadTXD ("files/dft30.txd")
engineImportTXD (txd, 578)
dff = engineLoadDFF ("files/dft30.dff")
engineReplaceModel (dff,578,true)

-- Enforcer / GTA5
txd = engineLoadTXD ("files/enforcer.txd")
engineImportTXD (txd, 427)
dff = engineLoadDFF ("files/enforcer.dff")
engineReplaceModel (dff,427,true)

-- FBI Rancher / Chevy Tahoe
txd = engineLoadTXD ("files/FBIrancher.txd")
engineImportTXD (txd, 490)
dff = engineLoadDFF ("files/FBIrancher.dff")
engineReplaceModel (dff,490,true)

-- Firetruck / NYFD
txd = engineLoadTXD ("files/firetruck.txd")
engineImportTXD (txd, 407)
dff = engineLoadDFF ("files/firetruck.dff")
engineReplaceModel (dff,407,true)

-- Glendale Shit / Pontiac
txd = engineLoadTXD ("files/glendale.txd")
engineImportTXD (txd, 604)
dff = engineLoadDFF ("files/glendale.dff")
engineReplaceModel (dff,604,true)

-- Hotring Racer / BMW M3
txd = engineLoadTXD ("files/bmwe30.txd")
engineImportTXD (txd, 494)
dff = engineLoadDFF ("files/bmwe30.dff")
engineReplaceModel (dff,494,true)

-- landstalker / Mercedes G Wagon
txd = engineLoadTXD ("files/landstal.txd")
engineImportTXD (txd, 400)
dff = engineLoadDFF ("files/landstal.dff")
engineReplaceModel (dff,400,true)

-- News van / Custom
txd = engineLoadTXD ("files/genericvan.txd")
engineImportTXD (txd, 582)
dff = engineLoadDFF ("files/genericvan.dff")
engineReplaceModel (dff,582,true)

-- Police LS / Crown Vic
txd = engineLoadTXD ("files/copcarla.txd")
engineImportTXD (txd, 596)
dff = engineLoadDFF ("files/copcarla.dff")
engineReplaceModel (dff,596,true)

-- Police LV / GTA5
txd = engineLoadTXD ("files/copcarvg.txd")
engineImportTXD (txd, 598)
dff = engineLoadDFF ("files/copcarvg.dff")
engineReplaceModel (dff,598,true)

-- Police SF / Sultan
txd = engineLoadTXD ("files/copcarsf.txd")
engineImportTXD (txd, 597)
dff = engineLoadDFF ("files/copcarsf.dff")
engineReplaceModel (dff,597,true)

-- Previon / Silvia
txd = engineLoadTXD ("files/silvia.txd")
engineImportTXD (txd, 436)
dff = engineLoadDFF ("files/silvia.dff")
engineReplaceModel (dff,436,true)

-- Roadtrain / Custom
txd = engineLoadTXD ("files/rdtrain.txd")
engineImportTXD (txd, 515)
dff = engineLoadDFF ("files/rdtrain.dff")
engineReplaceModel (dff,515,true)

-- Sentinel / BMW M5
txd = engineLoadTXD ("files/sentinel.txd")
engineImportTXD (txd, 405)
dff = engineLoadDFF ("files/sentinel.dff")
engineReplaceModel (dff,405,true)

-- Super GT / Ford Shelby GR1
txd = engineLoadTXD ("files/supergt.txd")
engineImportTXD (txd, 506)
dff = engineLoadDFF ("files/supergt.dff")
engineReplaceModel (dff,506,true)

-- Tampa / GTA5
txd = engineLoadTXD ("files/tampa.txd")
engineImportTXD (txd, 549)
dff = engineLoadDFF ("files/tampa.dff")
engineReplaceModel (dff,549,true)

-- Tornado / Custom
dff = engineLoadDFF ("files/tornado.dff")
engineReplaceModel (dff,576,true)

-- Turismo / Lamborghini
txd = engineLoadTXD ("files/turismo.txd")
engineImportTXD (txd, 451)
dff = engineLoadDFF ("files/turismo.dff")
engineReplaceModel (dff,451,true)