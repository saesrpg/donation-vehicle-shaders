-- do not make any changes to this file


-- Shader code
theTechnique = dxCreateShader( "shader.fx" )

theTechnique = dxCreateShader("shader.fx")
wrapTexture = dxCreateTexture( "wrap.png")

function replaceEffect()
	engineApplyShaderToWorldTexture(theTechnique, "?emap*", theVehicle)
	engineApplyShaderToWorldTexture(theTechnique, "remapsultanbody256", theVehicle)
	engineApplyShaderToWorldTexture(theTechnique, "dirt", theVehicle)
	engineApplyShaderToWorldTexture(theTechnique, "white1024", theVehicle)
	engineApplyShaderToWorldTexture(theTechnique, "Shamalbody256", theVehicle)
	engineApplyShaderToWorldTexture(theTechnique, "tornado92body256b", theVehicle)
	engineApplyShaderToWorldTexture(theTechnique, "nrg50092body128", theVehicle)
	engineApplyShaderToWorldTexture(theTechnique, "main_wrap", theVehicle)
	dxSetShaderValue (theTechnique, "gTexture", wrapTexture)
end
addEventHandler("onClientResourceStart",resourceRoot,replaceEffect)